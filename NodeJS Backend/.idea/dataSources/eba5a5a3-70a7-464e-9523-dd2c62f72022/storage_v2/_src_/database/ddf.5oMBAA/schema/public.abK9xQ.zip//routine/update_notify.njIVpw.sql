create function update_notify() returns trigger
    language plpgsql
as
$$
DECLARE
    name varchar(150);
    timestamp timestamp;
    price bigint;
    is_new boolean;
BEGIN
    IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN
        name = NEW.name;
        timestamp = new.timestamp;
        price = new.price;
        is_new = true;
        PERFORM pg_notify('new_price', json_build_object('table', TG_TABLE_NAME,'is_new', is_new, 'name', name, 'timestamp', timestamp, 'price',price, 'type', TG_OP)::text);
        RETURN NEW;
    ELSE
        name = old.name;
        timestamp = old.timestamp;
        price = old.price;
        is_new = false;
    END IF;
END;
$$;

alter function update_notify() owner to postgres;

