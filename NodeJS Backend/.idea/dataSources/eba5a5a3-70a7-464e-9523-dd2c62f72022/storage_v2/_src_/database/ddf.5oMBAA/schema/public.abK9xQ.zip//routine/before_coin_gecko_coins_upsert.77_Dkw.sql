create function before_coin_gecko_coins_upsert() returns trigger
    language plpgsql
as
$$
BEGIN
    BEGIN
        IF NEW.last_updated > OLD.last_updated THEN
            RETURN NEW;
        ELSE
            return OLD;
        END IF;
    END;
END;
$$;

alter function before_coin_gecko_coins_upsert() owner to postgres;

