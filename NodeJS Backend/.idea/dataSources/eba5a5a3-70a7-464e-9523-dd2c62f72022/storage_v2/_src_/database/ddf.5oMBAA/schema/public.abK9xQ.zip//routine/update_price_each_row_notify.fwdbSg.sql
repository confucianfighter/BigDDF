create function update_price_each_row_notify() returns trigger
    language plpgsql
as
$$
DECLARE
    symbol varchar;
    timestamp timestamp;
    price decimal;
    is_new boolean;
BEGIN
    IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN

        symbol = new.symbol;
        price = new.price;
        timestamp = new.timestamp;
        is_new = true;
        PERFORM pg_notify('price_update', json_build_object('table', TG_TABLE_NAME,'is_new', is_new, 'symbol', symbol, 'timestamp', timestamp, 'price',price, 'type', TG_OP)::text);
        RETURN new;
    ELSE
        /*timestamp = old.timestamp;*/
        /*price = old.price;*/
        is_new = false;
    END IF;
END;
$$;

alter function update_price_each_row_notify() owner to postgres;

