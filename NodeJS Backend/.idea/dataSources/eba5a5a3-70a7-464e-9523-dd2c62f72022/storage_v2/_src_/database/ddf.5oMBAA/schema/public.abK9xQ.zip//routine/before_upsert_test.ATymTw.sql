create function before_upsert_test() returns trigger
    language plpgsql
as
$$
BEGIN
    BEGIN
        IF NEW.date > OLD.date THEN
            RETURN NEW;
        ELSE
            return OLD;
        END IF;
    END;
END;
$$;

alter function before_upsert_test() owner to postgres;

