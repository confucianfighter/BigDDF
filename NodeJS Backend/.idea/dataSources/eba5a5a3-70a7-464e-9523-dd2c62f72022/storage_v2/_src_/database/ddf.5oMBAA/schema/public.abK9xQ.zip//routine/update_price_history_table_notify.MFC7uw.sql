create function update_price_history_table_notify() returns trigger
    language plpgsql
as
$$
BEGIN
    PERFORM pg_notify('price_history_table_update', tg_table_name::text);
    RETURN NEW;
END;
$$;

alter function update_price_history_table_notify() owner to postgres;

